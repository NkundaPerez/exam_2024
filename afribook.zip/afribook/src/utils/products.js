import productImg01 from "../Images/1.jpg";
import productImg02 from "../Images/2.jpg";
import productImg03 from "../Images/3.jpg";

import productImg04 from "../Images/4.jpg";
import productImg05 from "../Images/5.jpg";
import productImg06 from "../Images/6.jpg";
import productImg007 from "../Images/7.jpg";

import productImg07 from "../Images/8.jpg";
import productImg08 from "../Images/9.jpg";
import productImg09 from "../Images/10.jpg";
import productImg10 from "../Images/11.jpg";

import phone01 from "../Images/12.jpg";
import phone02 from "../Images/13.png";
import phone03 from "../Images/14.jpg";
import phone04 from "../Images/15.jpg";
import phone05 from "../Images/16.jpg";
import phone06 from "../Images/18.jpg";
import phone08 from "../Images/19.jpg";

import watch01 from "../Images/20.jpg";
import watch02 from "../Images/21.jpg";
import watch03 from "../Images/22.jpg";
import watch04 from "../Images/23.jpg";

import wireless01 from "../Images/f.jpg";
import wireless02 from "../Images/f2.jpg";
import wireless03 from "../Images/f3.jpg";
import wireless04 from "../Images/f4.jpg";

import sofaSlide from "../Images/f5.jpg";
import watchSlide from "../Images/f6.jpg";

export const SliderData = [
  {
      id: 1,
      title: "50% Off For Your First Book Shopping",
      desc: "East African literature is open to all people in the horn of africa and the Coast ,the land locked we shall improve the language ",
      cover: sofaSlide,
  },
  {
      id: 2,
      title: "50% Off For Your First Shopping",
      desc: "welcomes readers from any background in East Africa..",
      cover: phone08,
  },
  {
      id: 3,
      title: "50% Off For Your First Shopping",
      desc: "hint at the range of settings in East African literature.",
      cover: wireless01,
  },
  {
      id: 4,
      title: "50% Off For Your First Shopping",
      desc: "positions books as gateways to new experiences..",
      cover: watchSlide,
  },
];

export const serviceData = [
  {
    icon: <ion-icon name="car"></ion-icon>,
    title: "Free Shipping",
    subtitle: "Save on every story.",
    bg: "#fdefe6",
  },
  {
    icon: <ion-icon name="card"></ion-icon>,
    title: "Safe Payment",
    subtitle: "Safe & Secure Checkout.",
    bg: "#ceebe9",
  },
  {
    icon: <ion-icon name="shield-half-outline"></ion-icon>,
    title: "Secure Payment",
    subtitle: "Shop with peace of mind.",
    bg: "#e2f2b2",
  },
  {
    icon: <ion-icon name="headset"></ion-icon>,
    title: " Back Guarantee",
    subtitle: "100% Satisfaction Guaranteed..",
    bg: "#d6e5fb",
  },
];

export const discoutProducts = [
  {
    id: "01",
    productName: "African Risen ",
    imgUrl: productImg01,
    category: "friction",
    price: 193,
    discount:30,
    shortDesc:
      "A New Era of Speculative Fiction is an anthology, ",
    description:
      "not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach",
    reviews: [
      {
        rating: 4.7,
        text: "Good.",
      },
    ],
    avgRating: 4.5,
  },
  {
    id: "02",
    productName: "Half of a yellow sun",
    imgUrl: productImg02,
    category: "sofa",
    price: 253,
    discount:20,
    shortDesc:
      "",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: ".",
      },
      {
        rating: 4.8,
        text: ".",
      },
    ],
    avgRating: 4.7,
  },
  {
    id: "08",
    productName: "East Africa",
    imgUrl: productImg08,
    category: "fanatacy ",
    price: 89,
    discount:15,
    shortDesc:
      "",
    description:
      "",
    reviews: [
      {
        rating: 4.6,
        text: "",
      },
      {
        rating: 4.9,
        text: ".",
      },
    ],
    avgRating: 4.7,
  },
  {
    id: "09",
    productName: "Revival",
    imgUrl: productImg09,
    category: "fantancy",
    price: 112,
    discount:35,
    shortDesc:
      "",
    description:
      "",
    reviews: [
      {
        rating: 4.6,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.7,
  },
  {
    id: "12",
    productName: "History of East Africa",
    imgUrl: phone03,
    category: "mobile book",
    price: 599,
    discount:10,
    shortDesc:
      "",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: ".",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },
  {
    id: "13",
    productName: "East African Revival",
    imgUrl: phone04,
    category: "mobile",
    price: 799,
    discount:5,
    shortDesc:
      "",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },

]

export const products = [
  {
    id: "01",
    productName: "African Risen ",
    imgUrl: productImg01,
    category: "fanatcy",
    price: 193,
    shortDesc:
      "",
    description:
      " is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.7,
        text: "",
      },
    ],
    avgRating: 4.5,
  },

  {
    id: "02",
    productName: "Half of a yellow sun ",
    imgUrl: productImg02,
    category: "Inspiration",
    price: 253,
    shortDesc:
      "is a historical fiction novel written by Chimamanda Ngozi Adichie. Published in 2006, the story unfolds against the backdrop of the Nigerian Civil War (1967-1970).  It follows the lives of intertwined characters, including twin sisters Olanna and Kainene, navigating love, loss, and the brutal realities of war. The title itself references the flag of Biafra, the breakaway state at the center of the conflict, which featured a half yellow sun.",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.8,
        text: "",
      },
    ],
    avgRating: 4.7,
  },

  {
    id: "03",
    productName: "Rivival",
    imgUrl: productImg03,
    category: "Fiction",
    price: 173,
    shortDesc:
      "the region boasts a rich literary heritage. If you're interested in fiction, explore coming-of-age stories like Ngũgĩ wa Thiong'o's Weep Not, Child set in colonial Kenya , or Chimamanda Ngozi Adichie's Half of a Yellow Sun, a historical fiction novel following characters during the Nigerian Civil War . For non-fiction, delve into the region's history with East Africa: A History by Robert M. Maxon or A History of East Africa by E. S. Atieno Odhiambo , or plan your East African adventure with Lonely Planet's East Africa travel guide .",
    description:
      "",
    reviews: [
      {
        rating: 4.6,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.7,
  },
  {
    id: "26",
    productName: "Half of a yellow sun ",
    imgUrl: productImg02,
    category: "friction",
    price: 253,
    shortDesc:
      "",
    description:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.8,
        text: "",
      },
    ],
    avgRating: 4.7,
  },
  {
    id: "04",
    productName: "African Chief",
    imgUrl: productImg04,
    category: "horror",
    price: 163,
    shortDesc:
      "",
    description:
      " is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.6,
        text: ".",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.7,
  },

  {
    id: "05",
    productName: "Nesson EA tribute",
    imgUrl: productImg05,
    category: "fantacy",
    price: 163,
    shortDesc:
      "good",
    description:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.6,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.7,
  },

  {
    id: "06",
    productName: "Birds",
    imgUrl: productImg06,
    category: "love ",
    price: 163,
    shortDesc:
      "",
    description:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.6,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.7,
  },
  {
    id: "07",
    productName: "African Doctor",
    imgUrl: productImg07,
    category: "horror",
    price: 99,
    shortDesc:
      "",
    description:
      " is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.6,
        text: ".",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.7,
  },

  {
    id: "27",
    productName: "The Unexpected Guest",
    imgUrl: productImg007,
    category: "love",
    price: 173,
    shortDesc:
      "by Moses Isegawa (Uganda): A humorous and heartwarming tale about an unexpected visitor who disrupts the lives of a Ugandan family, leading to self-reflection and growth.",
    description:
      "",
    reviews: [
      {
        rating: 4.6,
        text: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
      },
      {
        rating: 4.9,
        text: "Lorem ipsum dolor sit amet consectetur adipisicing elit.",
      },
    ],
    avgRating: 4.7,
  },

  {
    id: "08",
    productName: "Tram 83",
    imgUrl: productImg08,
    category: "funtancy",
    price: 89,
    shortDesc:
      "by Marie-Claire Rupia (Rwanda): A moving collection of short stories that offer a glimpse into the lives of Rwandan women rebuilding their lives after the devastation of genocide.",
    description:
      "",
    reviews: [
      {
        rating: 4.6,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.7,
  },

  {
    id: "09",
    productName: "Kintu",
    imgUrl: productImg09,
    category: "fantacy",
    price: 112,
    shortDesc:
      "A fast-paced crime novel set in bustling Lagos, Nigeria, where a chance encounter on a crowded tram leads a journalist into a dangerous investigation",
    description:
      "",
    reviews: [
      {
        rating: 4.6,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.7,
  },

  {
    id: "10",
    productName: "The Promise",
    imgUrl: phone01,
    category: "fantacy",
    price: 799,
    shortDesc:
      "",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },
  {
    id: "25",
    productName: "Land of Secretsr",
    imgUrl: productImg10,
    category: "floating",
    price: 99,
    shortDesc:
      "by Ahmed Yusuf (Somalia): A suspenseful thriller set in contemporary Somalia, where a journalist uncovers a dangerous web of corruption and political intrigue.",
    description:
      "",
    reviews: [
      {
        rating: 4.6,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.7,
  },
  {
    id: "11",
    productName: "Tailor-Made",
    imgUrl: phone02,
    category: "fantacy",
    price: 799,
    shortDesc:
      "",
    description:
      "by Meselech Ashenafi (Ethiopia): A captivating historical novel exploring the life of Ethiopia's first female tailor, who defied societal norms to establish a successful business in the early 20th century.",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "12",
    productName: "The Girl with the Louding Voice",
    imgUrl: phone03,
    category: "love",
    price: 599,
    shortDesc:
      " A powerful novel told from the perspective of a fearless Nigerian teenager who fights for her education and dreams against societal expectations.",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "13",
    productName: "Beneath the Acacia Trees",
    imgUrl: phone04,
    category: "love",
    price: 799,
    shortDesc:
      "by Mwathi wa Mwangi (Kenya): A coming-of-age story set in a small Kenyan village, following a young girl's journey of self-discovery amidst cultural traditions and social change.",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "14",
    productName: "Rich African",
    imgUrl: phone05,
    category: "MOTIVATION",
    price: 899,
    shortDesc:
      "",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "15",
    productName: "Tokiyaa the young teen",
    imgUrl: phone06,
    category: "mobile",
    price: 699,
    shortDesc:
      "",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: ".",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "16",
    productName: "Kintu Nambi",
    imgUrl: watch01,
    category: "horror",
    price: 299,
    shortDesc:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: ".",
      },
      {
        rating: 4.9,
        text: ".",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "17",
    productName: "Peter Pan ",
    imgUrl: watch02,
    category: "love",
    price: 299,
    shortDesc:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    description:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: ".",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "18",
    productName: "Cowory of hope",
    imgUrl: watch03,
    category: "love",
    price: 299,
    shortDesc:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: ".",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "19",
    productName: "African literature",
    imgUrl: watch04,
    category: "FRee style",
    price: 399,
    shortDesc:
      "",
    description:
      "",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "20",
    productName: "Nelson life",
    imgUrl: wireless01,
    category: "inspiration",
    price: 199,
    shortDesc:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    description:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: ".",
      },
    ],
    avgRating: 4.8,
  },

  {
    id: "21",
    productName: "For the Records",
    imgUrl: wireless03,
    category: "fantacy",
    price: 199,
    shortDesc:
      "",
    description:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.8,
        text: ".",
      },
      {
        rating: 4.9,
        text: ".",
      },
    ],
    avgRating: 4.8,
  },
  {
    id: "22",
    productName: "African Plant Collector",
    imgUrl: wireless02,
    category: "Studying",
    price: 169,
    shortDesc:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    description:
      "is an anthology, not a single book, edited by Sheree Renée Thomas, Zelda Knight, and Oghenechovwe Donald Ekpeki. Published in 2022, it features 32 original stories by various African and African diaspora authors, showcasing the diversity and power of speculative fiction within the African continent and its global reach.",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: "",
      },
    ],
    avgRating: 4.8,
  },
  {
    id: "23",
    productName: "Shia nchii african book",
    imgUrl: wireless04,
    category: "education",
    price: 139,
    shortDesc:
      "",
    description:
      " ",
    reviews: [
      {
        rating: 4.8,
        text: "",
      },
      {
        rating: 4.9,
        text: ".",
      },
    ],
    avgRating: 4.8,
  },

];
